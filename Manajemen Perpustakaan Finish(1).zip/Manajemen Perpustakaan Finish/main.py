from database.database import connect
from services.perpustakaan import Perpustakaan


connect()

perpus = Perpustakaan()

while True:

    print("\n=== SISTEM MANAJEMEN PERPUSTAKAAN ===")
    print("1. Tambah Buku")
    print("2. Lihat Buku")
    print("3. Update Buku")
    print("4. Hapus Buku")
    print("5. Keluar")

    menu = input("Pilih menu: ")

    if menu == "1":

        judul = input("Judul Buku: ")
        penulis = input("Penulis: ")
        tahun = input("Tahun: ")

        perpus.tambah_buku(judul, penulis, tahun)

    elif menu == "2":

        perpus.lihat_buku()

    elif menu == "3":

        id_buku = input("ID Buku: ")
        judul = input("Judul Baru: ")

        perpus.update_buku(id_buku, judul)

    elif menu == "4":

        id_buku = input("ID Buku: ")

        perpus.hapus_buku(id_buku)

    elif menu == "5":

        print("Program selesai")
        break

    else:
        print("Menu tidak tersedia")
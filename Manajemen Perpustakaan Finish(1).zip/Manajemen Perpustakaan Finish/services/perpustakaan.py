import sqlite3
from models.class_book import Buku


class Perpustakaan:

    def tambah_buku(self, judul, penulis, tahun):

        buku = Buku(judul, penulis, tahun)

        conn = sqlite3.connect("perpustakaan.db")
        cursor = conn.cursor()

        cursor.execute(
        "INSERT INTO buku (judul, penulis, tahun, status) VALUES (?,?,?,?)",
        (buku.judul, buku.penulis, buku.tahun, buku.status)
        )

        conn.commit()
        conn.close()

        print("Buku berhasil ditambahkan")


    def lihat_buku(self):

        conn = sqlite3.connect("perpustakaan.db")
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM buku")

        data = cursor.fetchall()

        for buku in data:
            print("ID:", buku[0])
            print("Judul:", buku[1])
            print("Penulis:", buku[2])
            print("Tahun:", buku[3])
            print("Status:", buku[4])
            print("------------------")

        conn.close()


    def hapus_buku(self, id_buku):

        conn = sqlite3.connect("perpustakaan.db")
        cursor = conn.cursor()

        cursor.execute(
        "DELETE FROM buku WHERE id=?",
        (id_buku,)
        )

        conn.commit()
        conn.close()

        print("Buku dihapus")


    def update_buku(self, id_buku, judul_baru):

        conn = sqlite3.connect("perpustakaan.db")
        cursor = conn.cursor()

        cursor.execute(
        "UPDATE buku SET judul=? WHERE id=?",
        (judul_baru, id_buku)
        )

        conn.commit()
        conn.close()

        print("Buku berhasil diupdate")
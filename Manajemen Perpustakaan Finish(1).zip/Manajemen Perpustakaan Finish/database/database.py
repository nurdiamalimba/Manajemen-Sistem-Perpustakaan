import sqlite3

def connect():

    conn = sqlite3.connect("perpustakaan.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS buku(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        judul TEXT,
        penulis TEXT,
        tahun INTEGER,
        status TEXT
    )
    """)

    conn.commit()
    conn.close()

    print("Database siap digunakan")
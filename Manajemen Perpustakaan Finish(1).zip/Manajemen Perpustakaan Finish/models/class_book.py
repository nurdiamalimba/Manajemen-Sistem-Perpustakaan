class Buku:

    def __init__(self, judul, penulis, tahun, status="Tersedia"):
        self.judul = judul
        self.penulis = penulis
        self.tahun = tahun
        self.status = status

    def info(self):
        return f"{self.judul} - {self.penulis} ({self.tahun}) [{self.status}]"


# Buku Fiksi
class BukuFiksi(Buku):

    def kategori(self):
        return "Fiksi"


# Buku Non Fiksi
class BukuNonFiksi(Buku):

    def kategori(self):
        return "Non Fiksi"